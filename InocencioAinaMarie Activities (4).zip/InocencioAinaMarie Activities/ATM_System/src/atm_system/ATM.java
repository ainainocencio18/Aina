/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm_system;

/**
 *
 * @author acer
 */
public class ATM {
    public Screen screen;
    public Keyboard keyboard;
    private Calculator1 calculator1;

    public ATM()
   {
      screen = new Screen();
      keyboard = new Keyboard();
      calculator1 = new Calculator1();
      
   }
   public void run()
   {
       screen.println("Enter your Name: ");
       String name = keyboard.getString();
       screen.println("Enter your Age: ");
       int age = keyboard.getInt();
        screen.println("Enter your Height: ");
       double height = keyboard.getDouble();
       
       
       
       screen.println("Enter your First Number: ");
          double a = keyboard.getDouble();
          screen.println("Enter your Second Number: ");
         double b = keyboard.getDouble();
         
         double sum = calculator1.sum(a,b);
         screen.println("The Sum is: " +sum);
          
         double multiplication = calculator1.multiplication(a,b);
         screen.println("The Product is: " +multiplication);
         
         double division = calculator1.division(a,b);
         screen.println("The Quotient is: " +division);
       
         double subtraction = calculator1.subtraction(a,b);
         screen.println("The Difference is: "+subtraction);
   }
}
