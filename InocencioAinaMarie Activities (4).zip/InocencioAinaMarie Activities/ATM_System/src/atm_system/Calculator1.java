/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm_system;

/**
 *
 * @author acer
 */
public class Calculator1 {
    public double sum(double x, double y)
    {
       return x+y;
    }
    public double multiplication(double x, double y)
    {
     return x*y;
    }
    public double division(double x, double y)
    {
      return x/y;   
      
    }
    public double subtraction(double x, double y) 
    {
       return x-y;     
    }
}
