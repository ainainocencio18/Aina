/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm_system;

/**
 *
 * @author acer
 */
public class Screen {
  public void println(String message)
 {
    System.out.println(message);
 }
      public void println(int message)
 {
    System.out.println(message);
 }
  public void println(double message)
{
      System.out.println(message);
}

 
    }

