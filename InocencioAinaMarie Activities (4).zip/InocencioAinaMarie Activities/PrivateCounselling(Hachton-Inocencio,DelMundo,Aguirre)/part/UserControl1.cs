﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace part
{
    public partial class UserControl1 : UserControl

    {
       
        string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\acer\Documents\Visual Studio 2013\Projects\part\part\Database1.mdf;Integrated Security=True";
        private object table;
        public UserControl1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\acer\Documents\Visual Studio 2013\Projects\part\part\Database1.mdf;Integrated Security=True");
        int selectedRow;
        private void button5_Click(object sender, EventArgs e)
        {
             DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to exit.", "EXIT?", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (iExit == DialogResult.Yes)
            {
                frm_admin home = new frm_admin();
                home.Show();
                this.Hide();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM tbl_message", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        
       
        private void UserControl1_Load_1(object sender, EventArgs e)
        {
            

            panel1.BackColor = Color.FromArgb(100, 0, 0, 0);
            DataTable table = new DataTable();
           
            table.Columns.Add("Username", typeof(string));
            table.Columns.Add("Message", typeof(string));
            table.Columns.Add("Date", typeof(string));

            dataGridView1.DataSource = table;



            dataGridView1.Columns[0].HeaderCell.Style.Font = new Font("Rockwell", 10, FontStyle.Bold);
            dataGridView1.Columns[1].HeaderCell.Style.Font = new Font("Rockwell", 10, FontStyle.Bold);
            dataGridView1.Columns[2].HeaderCell.Style.Font = new Font("Rockwell", 10, FontStyle.Bold);

            dataGridView1.Columns[0].DefaultCellStyle.Font = new Font("Rockwell", 10, FontStyle.Regular);
            dataGridView1.Columns[1].DefaultCellStyle.Font = new Font("Rockwell", 12, FontStyle.Regular);
            dataGridView1.Columns[2].DefaultCellStyle.Font = new Font("Rockwell", 10, FontStyle.Regular);

            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(238, 239, 249);
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridView1.DefaultCellStyle.SelectionBackColor = Color.DarkTurquoise;
            dataGridView1.DefaultCellStyle.SelectionForeColor = Color.Black;
            dataGridView1.BackgroundColor = Color.White;

            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(20, 25, 72);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

        }

         private void pictureBox1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "DELETE FROM tbl_message";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            sda.SelectCommand.ExecuteNonQuery();
            con.Close();
            dataGridView1.Rows.RemoveAt(selected);
            DialogResult iExit;
            iExit = MessageBox.Show("Are you sure you want to delete?.", "DELETE", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (iExit == DialogResult.Yes)
            {
                MessageBox.Show("Successfully deleted");
            }
        }

        

       
    
public  int selected { get; set; }

private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
{
    selectedRow = e.RowIndex;
    DataGridViewRow row = dataGridView1.Rows[selectedRow];
    textBox1.Text = row.Cells[0].Value.ToString();
    textBox2.Text = row.Cells[1].Value.ToString();
    textBox3.Text = row.Cells[2].Value.ToString();
}
    }
    }

