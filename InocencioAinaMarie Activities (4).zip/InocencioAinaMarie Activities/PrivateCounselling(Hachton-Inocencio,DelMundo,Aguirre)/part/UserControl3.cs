﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace part
{
    public partial class UserControl3 : UserControl
    {
        SqlCommand cmd;
        SqlConnection con;
        SqlDataAdapter sda;
        public UserControl3()
        {
            InitializeComponent();
        }

        

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\acer\Documents\Visual Studio 2013\Projects\part\part\Database1.mdf;Integrated Security=True");
            con.Open();
            cmd = new SqlCommand("INSERT INTO tbl_message(Username,Message,Date)VALUES(@Username,@Message,@Date)", con);
            cmd.Parameters.AddWithValue("@Message", textBox1.Text);
            cmd.Parameters.AddWithValue("@Username", textBox2.Text);
            cmd.Parameters.AddWithValue("@Date", dateTimePicker1.Text);
            cmd.ExecuteNonQuery();

            MessageBox.Show("Send Successfully");  
        }

        private void UserControl3_Load(object sender, EventArgs e)
        {
            panel1.BackColor = Color.FromArgb(100, 0, 0, 0);
        }
    }
}
