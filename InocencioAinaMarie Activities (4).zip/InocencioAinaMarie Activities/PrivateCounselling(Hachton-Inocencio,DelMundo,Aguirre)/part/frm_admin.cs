﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace part
{
    public partial class frm_admin : Form
    {
      
        public frm_admin()
        {
            InitializeComponent();
        }




        private void button1_Click_1(object sender, EventArgs e)
        {
            
            if (textBox3.Text == "")
            {
                textBox3.Focus();
                label7.Visible = true;

            }

            if (textBox4.Text == "")
            {
                textBox4.Focus();
                label8.Visible = true;

            }

            else
            {
                fn.sql = "SELECT * FROM user_table WHERE admin_username = '" + textBox3.Text + "'";
                try
                {
                    fn.connDB();
                    SqlCommand query = new SqlCommand(fn.sql, fn.conn);
                    SqlDataReader row = query.ExecuteReader();
                    if (!row.Read())
                    {
                        textBox3.Focus();
                        label7.Visible = true;
                        label7.Text = "Username doesn't exists.";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                fn.sql = "SELECT * FROM user_table WHERE admin_password = '" + textBox4.Text + "'";
                try
                {
                    fn.connDB();
                    SqlCommand query = new SqlCommand(fn.sql, fn.conn);
                    SqlDataReader row = query.ExecuteReader();
                    if (!row.Read())
                    {
                        textBox4.Focus();
                        label8.Visible = true;
                        label8.Text = "Password incorrect. Please try again";
                    }
                    else
                    {
                        frm_adminhome home = new frm_adminhome();
                        home.Show();
                        this.Hide();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
            }
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {

            fn.sql = "SELECT * FROM user_table WHERE admin_username = '" + textBox3.Text + "'";
            try
            {
                fn.connDB();
                SqlCommand query = new SqlCommand(fn.sql, fn.conn);
                SqlDataReader row = query.ExecuteReader();
                if (!row.Read())
                {
                    label7.Visible = true;
                    label7.Text = "Username doesn't exists.";
                }
                else
                {
                    label7.Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            label8.Visible = false;
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            label7.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
           frm_admin log = new frm_admin();
            log.Show();
            this.Hide();
        }

        private void frm_admin_Load(object sender, EventArgs e)
        {
            textBox4.UseSystemPasswordChar = true; 
            panel4.BackColor = Color.FromArgb(100, 0, 0, 0);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to exit", "EXIT", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (iExit == DialogResult.Yes)
            {
                frm_admin home = new frm_admin();
                home.Show();
                this.Hide();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox4.UseSystemPasswordChar = true;
            }
            else
            {
                textBox4.UseSystemPasswordChar = false;
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                textBox3.Focus();
                label7.Visible = true;

            }

            if (textBox4.Text == "")
            {
                textBox4.Focus();
                label8.Visible = true;

            }

            else
            {
                fn.sql = "SELECT * FROM user_table WHERE admin_username = '" + textBox3.Text + "'";
                try
                {
                    fn.connDB();
                    SqlCommand query = new SqlCommand(fn.sql, fn.conn);
                    SqlDataReader row = query.ExecuteReader();
                    if (!row.Read())
                    {
                        textBox3.Focus();
                        label7.Visible = true;
                        label7.Text = "Username doesn't exists.";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                fn.sql = "SELECT * FROM user_table WHERE admin_password = '" + textBox4.Text + "'";
                try
                {
                    fn.connDB();
                    SqlCommand query = new SqlCommand(fn.sql, fn.conn);
                    SqlDataReader row = query.ExecuteReader();
                    if (!row.Read())
                    {
                        textBox4.Focus();
                        label8.Visible = true;
                        label8.Text = "Password incorrect. Please try again";
                    }
                    else
                    {
                        frm_adminhome home = new frm_adminhome();
                        home.Show();
                        this.Hide();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
            }
        }

        private void textBox3_KeyUp(object sender, KeyEventArgs e)
        {

            fn.sql = "SELECT * FROM user_table WHERE admin_username = '" + textBox3.Text + "'";
            try
            {
                fn.connDB();
                SqlCommand query = new SqlCommand(fn.sql, fn.conn);
                SqlDataReader row = query.ExecuteReader();
                if (!row.Read())
                {
                    label7.Visible = true;
                    label7.Text = "Username doesn't exists.";
                }
                else
                {
                    label7.Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            label8.Visible = false;
        }

        private void textBox3_Enter(object sender, EventArgs e)
        {
            label7.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                textBox3.Focus();
                label7.Visible = true;

            }

            if (textBox4.Text == "")
            {
                textBox4.Focus();
                label8.Visible = true;

            }

            else
            {
                fn.sql = "SELECT * FROM tbl_user WHERE Username = '" + textBox3.Text + "'";
                try
                {
                    fn.connDB();
                    SqlCommand query = new SqlCommand(fn.sql, fn.conn);
                    SqlDataReader row = query.ExecuteReader();
                    if (!row.Read())
                    {
                        textBox3.Focus();
                        label7.Visible = true;
                        label7.Text = "Username doesn't exists.";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                fn.sql = "SELECT * FROM tbl_user WHERE Password = '" + textBox4.Text + "'";
                try
                {
                    fn.connDB();
                    SqlCommand query = new SqlCommand(fn.sql, fn.conn);
                    SqlDataReader row = query.ExecuteReader();
                    if (!row.Read())
                    {
                        textBox4.Focus();
                        label8.Visible = true;
                        label8.Text = "Password incorrect. Please try again";
                    }
                    else
                    {
                        frm_userhome home = new frm_userhome();
                        home.Show();
                        this.Hide();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frm_register reg = new frm_register();
            reg.Show();
            this.Hide();
        }

        
        

        
        }
        }
    


