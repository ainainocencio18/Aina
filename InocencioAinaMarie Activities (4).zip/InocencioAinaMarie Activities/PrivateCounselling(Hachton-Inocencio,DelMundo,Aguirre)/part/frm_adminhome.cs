﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace part
{
    public partial class frm_adminhome : Form
    {
        public frm_adminhome()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to exit.", "EXIT?", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (iExit == DialogResult.Yes)
            {
                frm_admin home = new frm_admin();
                home.Show();
                this.Hide();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Are you sure you want to logout?", "LOGOUT?", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (iExit == DialogResult.Yes)
            {
                frm_admin home = new frm_admin();
                home.Show();
                this.Hide();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            
        }

        private void frm_adminhome_Load_1(object sender, EventArgs e)
        {
            userControl11.Hide();
            userControl21.Hide();
            userControl61.Hide();
        }
      
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            userControl61.Hide();
            userControl21.Hide();
            userControl11.Show();
            userControl11.BringToFront();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            userControl61.Hide();
            userControl11.Hide();
            userControl21.Show();
            userControl21.BringToFront();
           
        }

        private void userControl11_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            userControl21.Hide();
            userControl11.Hide();
            userControl61.Show();
            userControl61.BringToFront();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Are you sure you want to logout.", "LOGOUT?", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (iExit == DialogResult.Yes)
            {
                frm_admin home = new frm_admin();
                home.Show();
                this.Hide();
            }
        }

       
    }
}
