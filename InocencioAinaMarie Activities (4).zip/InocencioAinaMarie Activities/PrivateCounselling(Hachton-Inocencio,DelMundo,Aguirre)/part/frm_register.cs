﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace part
{
    public partial class frm_register : Form
    {
        SqlCommand cmd;
        SqlConnection con;
        SqlDataAdapter sda;

        public frm_register()
        {
            InitializeComponent();
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\acer\Documents\Visual Studio 2013\Projects\part\part\Database1.mdf;Integrated Security=True");
          
            con.Open();
            cmd = new SqlCommand("INSERT INTO tbl_user(User_ID,Firstname,Lastname,Username,Password)VALUES(@User_ID,@Firstname,@Lastname,@Username,@Password)", con);
            cmd.Parameters.AddWithValue("@User_ID", textBox5.Text);
            cmd.Parameters.AddWithValue("@Firstname", textBox1.Text);
            cmd.Parameters.AddWithValue("@Lastname", textBox2.Text);
            cmd.Parameters.AddWithValue("@Username", textBox3.Text);
            cmd.Parameters.AddWithValue("@Password", textBox4.Text);
            cmd.ExecuteNonQuery();

            DialogResult iExit;
            iExit = MessageBox.Show("Are you sure you want to save?", "SAVE?", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (iExit == DialogResult.Yes)
            {
                MessageBox.Show("Saved Successfully");  
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            frm_admin use = new frm_admin();
            use.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to exit.", "EXIT?", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (iExit == DialogResult.Yes)
            {
               frm_admin home = new frm_admin();
                home.Show();
                this.Hide();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            frm_admin ad = new frm_admin();
            ad.Show();
            this.Hide();

        }

        private void frm_register_Load(object sender, EventArgs e)
        {
            panel1.BackColor = Color.FromArgb(100, 0, 0, 0);
        }
    }
}
