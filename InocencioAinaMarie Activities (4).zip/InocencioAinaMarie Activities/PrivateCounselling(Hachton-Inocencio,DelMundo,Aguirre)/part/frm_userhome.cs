﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace part
{
    public partial class frm_userhome : Form
    {
        public frm_userhome()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
             DialogResult iExit;
            iExit = MessageBox.Show("Are you sure you want to Exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (iExit == DialogResult.Yes)
            {


                frm_admin log = new frm_admin();
                log.Show();
                this.Hide();
            }
        }

        private void frm_userhome_Load(object sender, EventArgs e)
        {
            
            userControl31.Hide();
            userControl41.Hide();
            userControl51.Hide();
            
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            userControl41.Hide();
            userControl51.Hide();
            userControl31.Show();
            userControl31.BringToFront();
        }

        

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            userControl31.Hide();
            userControl51.Hide();
            userControl41.Show();
            userControl41.BringToFront();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            userControl41.Hide();
            userControl31.Hide();
            userControl51.Show();
            userControl51.BringToFront();
        }

       

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Are you sure you want to Logout?", "LOGOUT", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (iExit == DialogResult.Yes)
            {


                frm_admin log = new frm_admin();
                log.Show();
                this.Hide();
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

       

       
       

     
       

        }
    }

